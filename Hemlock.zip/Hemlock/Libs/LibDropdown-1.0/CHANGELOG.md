# Lib: Dropdown-1.0

## [20240814](https://github.com/Addons-By-Neotron/LibDropDown/tree/20240814) (2024-08-14)
[Full Changelog](https://github.com/Addons-By-Neotron/LibDropDown/compare/20240724...20240814) [Previous Releases](https://github.com/Addons-By-Neotron/LibDropDown/releases)

- Update Interface version  
