# Lib: Dropdown-1.0

## [2022-01-20.1](https://github.com/neotron/WoW-LibDropDown/tree/2022-01-20.1) (2022-01-20)
[Full Changelog](https://github.com/neotron/WoW-LibDropDown/commits/2022-01-20.1) [Previous Releases](https://github.com/neotron/WoW-LibDropDown/releases)

- Use v2 checkout.  
